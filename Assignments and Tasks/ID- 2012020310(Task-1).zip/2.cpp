#include<iostream>
using namespace std;
int gcd(int a,int b);
int main()
{
    int a,b;
    cout<<"Enter two numbers : ";
    cin>>a>>b;
    int res = gcd(a,b);
    cout<<"Greatest Common Divisor = "<<res;
}
int gcd(int a,int b)
{
    if(b!=0 && a>b)
    {
        return gcd(b,a%b);
    }
    else if(b!=0 && a<b)
    {
        return gcd(a,b%a);
    }
}
