#include<iostream>
#include<string>
using namespace std;
int main()
{
    string st;
    getline(cin,st);
    int ln = st.size();
    if(ln%3==0)
    {
        cout<<"Divisible by 3"<<endl;
    }
    else
    {
        cout<<"Not divisible by 3"<<endl;
    }
}
