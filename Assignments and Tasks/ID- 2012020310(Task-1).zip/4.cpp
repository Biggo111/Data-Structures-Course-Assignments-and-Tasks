#include<iostream>
using namespace std;
#define PI 3.14159265
float area(int r);
int main()
{
    int r;
    cin>>r;
    float res = area(r);
    cout<<"Area of circle is "<<res;
}
float area(int r)
{
    return PI*r*r;
}
