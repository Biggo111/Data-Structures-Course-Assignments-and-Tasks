#include<iostream>
using namespace std;
int addition(int x,int y)
{
    return x+y;
}
int subtraction(int x,int y)
{
    if(x>y)
    {
        return x-y;
    }
    else if(x<y)
    {
        cout<<"\n\nYour second input is bigger than the first one.\n"<<endl;
        cout<<"\nSo the subtraction will be y-x\n"<<endl;
        return y-x;
    }
}
int multiplication(int x,int y)
{
    return x*y;
}
double division(double x,double y)
{
    if(x>y)
    {
        return x/y;
    }
    else if(x<y)
    {
        cout<<"\n\nYour second input is bigger than the first one.\n"<<endl;
        cout<<"\nSo the subtraction will be y/x\n"<<endl;
        return y/x;
    }
}
int mod(int x,int y)
{
    if(x>y)
    {
        return x%y;
    }
    else if(x<y)
    {
        cout<<"\n\nYour second input is bigger than the first one.\n"<<endl;
        cout<<"\nSo the subtraction will be y%x\n"<<endl;
        return y%x;
    }
}
int main()
{
    system("CLS");
    cout<<"\t\t\t\t\t\t  Welcome To My Calculator"<<endl;
    cout<<"\t\t\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<"\n\nYou can do five operations in this Calculator\n\n\n"<<endl;
    cout<<">>Press 1 To see Addition(+) of two numbers\n\n";
    cout<<">>Press 2 To see Subtraction(-) of two numbers\n\n";
    cout<<">>Press 3 To see Multiplication(*) of two numbers\n\n";
    cout<<">>Press 4 To see Division(/) of two numbers\n\n";
    cout<<">>Press 5 To see Reminder(%) of two numbers\n\n";
    int a,b,c;
    cout<<"\nEnter two numbers >> ";
    cin>>a>>b;
    cout<<"\n\nPress distinct number of your desired operation >> ";
    cin>>c;
    if(c==1)
    {
        system("CLS");
     int res = addition(a,b);
     cout<<"\n\n>> Addition = "<<res<<endl;
     int out;
     cout<<"\n\n\t\t\t\t\tPress 1 and press Enter To Get Back : ";
     cin>>out;
     if(out==1)
     {
         return main();
     }
    }
    else if(c==2)
    {
        system("CLS");
      int res = subtraction(a,b);
      cout<<"\n\n>> Subtraction = "<<res<<endl;
      int out;
     cout<<"\n\n\t\t\t\t\tPress 1 and press Enter To Get Back : ";
     cin>>out;
     if(out==1)
     {
         return main();
     }
    }
    else if(c==3)
    {
        system("CLS");
        int res = multiplication(a,b);
        cout<<"\n\n>> Multiplication = "<<res<<endl;
        int out;
     cout<<"\n\n\t\t\t\t\t\tPress 1 and press Enter To Get Back : ";
     cin>>out;
     if(out==1)
     {
         return main();
     }
    }
    else if(c==4)
    {
        system("CLS");
        double res = division(a,b);
        cout<<"\n\n>> Division = "<<res<<endl;
        int out;
        cout<<"\n\n\t\t\t\t\tPress 1 and press Enter To Get Back : ";
        cin>>out;
        if(out==1)
        {
            return main();
        }
    }
    else if(c==5)
    {
        system("CLS");
        int res = mod(a,b);
        cout<<"\n\n>> Reminder = "<<res<<endl;
        int out;
        cout<<"\n\n\t\t\t\t\tPress 1 and press Enter To Get Back : ";
        cin>>out;
        if(out==1)
        {
            return main();
        }
    }
}
