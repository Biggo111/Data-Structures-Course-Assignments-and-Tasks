#include<iostream>
using namespace std;
int summ(int n);
int main()
{
    int n;
    cout<<"Enter the number : ";
    cin>>n;
    int res = summ(n);
    cout<<"Summation = "<<res;
}
int summ(int n)
{
    int sum=0;
    if(n==0)
    {
        return 0;
    }
    sum = n + summ(n-1);
}
