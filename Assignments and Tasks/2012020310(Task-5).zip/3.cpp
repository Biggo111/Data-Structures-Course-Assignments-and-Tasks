//POST_ORDER
#include<bits/stdc++.h>
using namespace std;
int tree[25];
void root(int key)
{
    if(tree[1]!='\0') cout<<"Tree already had root"<<endl;
    else tree[1] = key;
}
void left_child(int key,int parent)
{
    if(tree[parent]=='\0') cout<<"\nCan't set child at"<<(parent*2)+2<<" ,no parent found"<<endl;
     tree[parent*2] = key;
}
void right_child(int key,int parent)
{
    if(tree[parent]=='\0') cout<<"\nCan't set child at"<<(parent*2)+2<<" ,no parent found"<<endl;
     tree[(parent*2)+1] = key;
}
void post_order(int parent)
{
    if(tree[parent*2]!=0)
    {
        post_order(parent*2);
    }

    if(tree[(parent*2)+1]!=0)
    {
        post_order((parent*2)+1);
    }
    cout<<tree[parent]<<" ";
}
int main()
{
    root(2);
    left_child(7,1);
    right_child(9,1);
    left_child(1,2);
    right_child(6,2);
    right_child(8,3);
    left_child(5,5);
    right_child(10,5);
    left_child(3,7);
    right_child(4,7);
    cout<<"POST-ORDER : ";
    post_order(1);
}


