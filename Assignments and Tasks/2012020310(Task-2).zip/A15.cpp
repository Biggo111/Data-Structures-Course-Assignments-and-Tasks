#include<iostream>
using namespace std;
int main()
{
   int n,arr[1000],coun=0;
   cin>>n;
   for(int i=0;i<n;i++)
   {
       cin>>arr[i];
   }
   for(int i=0;i<n;i++)
   {
       if(i==arr[i])
       {
           cout<<"Magic index is : "<<i;
           break;
       }
       else
       {
           coun++;
       }
   }
   if(coun==n)
   {
       cout<<"No Magic Index";
   }
}
