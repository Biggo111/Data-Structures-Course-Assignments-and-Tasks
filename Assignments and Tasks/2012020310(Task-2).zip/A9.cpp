#include<iostream>
using namespace std;
int main()
{
    int n,arr[1000],maxi=0,mini=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    maxi=arr[0];
    mini=arr[0];
    for(int i=0;i<n;i++)
    {
        if(arr[i]>maxi)
        {
            maxi=arr[i];
        }
        if(arr[i]<mini)
        {
            mini=arr[i];
        }
    }
    cout<<"Maximum Element is "<<maxi<<endl;
    cout<<"Minimum Element is "<<mini<<endl;
}
