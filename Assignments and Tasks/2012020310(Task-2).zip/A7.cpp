#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    int n1,i,j,k,arr[1000],arr2[1000],arr3[1000],tmp;
    cin>>n1;
    for(i=0;i<n1;i++)
    {
        cin>>arr[i];
    }
    int n2;
    cin>>n2;
    for(i=0;i<n2;i++)
    {
        cin>>arr2[i];
    }
    int n3 = n1 + n2;
    for(i=0;i<n1;i++)
    {
        arr3[i]=arr[i];
    }
    for(j=0;j<n2;j++)
    {
        arr3[i]=arr2[j];
        i++;
    }
    for(i=0;i<n3;i++)
    {
        for(k=0;k<n3-1;k++)
        {
            if(arr3[k]<arr3[k+1])
            {
                tmp=arr3[k+1];
                arr3[k+1]=arr3[k];
                arr3[k]=tmp;
            }
        }
    }
    for(i=0;i<n3;i++)
    {
        cout<<arr3[i];
    }
}
