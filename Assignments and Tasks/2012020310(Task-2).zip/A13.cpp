#include<iostream>
using namespace std;
int main()
{
    int n,arr[1000];
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"Enter the position: ";
    int pos;
    cin>>pos;
    for(int i=pos;i<n;i++)
    {
        arr[i]=arr[i+1];
    }
    n--;
    for(int i=0;i<n;i++)
    {
        cout<<arr[i];
    }
}
