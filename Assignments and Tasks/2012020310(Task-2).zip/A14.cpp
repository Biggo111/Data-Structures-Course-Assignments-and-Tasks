#include<iostream>
using namespace std;
int main()
{
    int n,arr[1000],tmp;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(arr[i]<arr[j])
            {
                tmp = arr[i];
                arr[i]=arr[j];
                arr[j]=tmp;
            }
        }
    }
    cout<<"Second largest element is : ";
    cout<<arr[1]<<endl;
    int mn=arr[0];
    for(int i=0;i<n;i++)
    {
        if(arr[i]<mn)
        {
            mn=arr[i-1];
        }
    }
    cout<<"Second smallest element is : ";
    cout<<mn;
}
