#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    int i,j,n,arr[1000];
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    for(i=0;i<n;i++)
    {
        for(j=0;i<n;j++)
        {
        if(arr[i]==arr[j])
        {
            break;
        }
        }
        if(i==j)
        {
          cout<<arr[i];
        }
    }
}
