#include<iostream>
using namespace std;
int main()
{
    int arr[1000];
    int n,i,j;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int value;
    cout<<"Enter the value: ";
    cin>>value;
    int a;
    for(i=0;i<n;i++)
    {
        if(value<arr[i])
        {
            a=i;
            break;
        }
    }

    for(i=n;i>=a;i--)
    {
        arr[i]=arr[i-1];
        arr[a]=value;
    }
    cout<<"The edited array is :"<<endl;
    for(int i=0;i<=n;i++)
    {
        cout<<arr[i]<<" ";
    }
}

