#include<iostream>
using namespace std;
int main()
{
    int n,i,j,arr[1000],arr2[1000],coun;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>arr[i];
        arr2[i]=-1;
    }
    for(i=0;i<n;i++)
    {
        coun=1;
        for(j=i+1;j<n;j++)
        {
            if(arr[i]==arr[j])
            {
                coun++;
                arr2[j]=0;
            }
        }
        if(arr2[i]!=0)
        {
            arr2[i]=coun;
        }
    }
    for(i=0;i<n;i++)
    {
        if(arr2[i]!=0)
        {
            cout<<arr[i]<<" are "<<arr2[i]<<" Times"<<endl;
        }
    }
}
