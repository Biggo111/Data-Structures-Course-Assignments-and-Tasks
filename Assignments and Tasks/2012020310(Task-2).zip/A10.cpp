#include<iostream>
using namespace std;
int main()
{
    int arr[1000],even[1000],odd[1000];
    int n,j=0,k=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    for(int i=0;i<n;i++)
    {
        if(arr[i]%2==0)
        {
            even[j]=arr[i];
            j++;
        }
        else
        {
            odd[k]=arr[i];
            k++;
        }
    }
    cout<<"Even elements are ";
    for(int i=0;i<j;i++)
    {
        cout<<even[i]<<" ";
    }
    cout<<endl;
    cout<<"Odd elements are ";
    for(int i=0;i<k;i++)
    {
        cout<<odd[i]<<" ";
    }
}
