#include<iostream>
#include<algorithm>
using namespace std;
int main()
{

    int i,j,n,arr[1000],arr2[1000];
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    for(i=n-1,j=0;i>=0;i--,j++)
    {
        arr2[i]=arr[j];
    }
    for(i=0;i<n;i++)
    {
        cout<<arr2[i];
    }
}

