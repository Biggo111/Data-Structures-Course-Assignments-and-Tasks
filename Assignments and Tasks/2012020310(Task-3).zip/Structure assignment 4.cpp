#include<bits/stdc++.h>
#include <iostream>
using namespace std;

struct student
{
    int id;
    string name;
    int age;
    string address;

};
void namee(student st[],int n)
{
    for(int i=0;i<n;i++)
    {
        if(st[i].age==14)
        {
            cout<< st[i].name <<"'s "<<"age is 14"<<endl;
        }
    }
}
void even(student st[],int n)
{
    for(int i=0;i<n;i++)
    {
        if(st[i].id%2==0)
        {
            cout<<st[i].name<<"'s "<<"Roll number is even"<<endl;
        }
    }
}
void detail(student st[],int n)
{
    int roll;
    cout<<"Enter roll number: ";
    cin>>roll;
    for(int i=0;i<n;i++)
    {
        if(st[i].id==roll)
        {
            cout << "Roll: " << st[i].id << endl;
            cout << "Name: " << st[i].name << endl;
            cout << "Age: "  << st[i].age <<endl;
            cout<<  "Address: "<<st[i].address<<endl;
        }
    }
}
int main()
{
    int n;
    cout<<"Enter the number of students: ";
    cin>>n;
    student st[n];
    for(int i=0;i<n;i++)
    {
    cout << "Enter Roll: ";
    cin >> st[i].id;
    cout << "Enter name: ";
    cin>>st[i].name;
    cout<<"Enter Age: ";
    cin>>st[i].age;
    cout<<"Enter Address: ";
    cin>>st[i].address;
    getchar();
    }
    namee(st,n);
    even(st,n);
    detail(st,n);
}
