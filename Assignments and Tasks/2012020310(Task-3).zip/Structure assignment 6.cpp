#include<bits/stdc++.h>
using namespace std;
typedef struct Date
{
    int day,month,year;
}datee;
int main()
{
    int n, d, m, y;
    cout<<"How many dates: ";
    cin>>n;
    datee DATE[n];
    for(int i=0; i<n; i++)
    {
        cout << "Day: ";
        cin >> DATE[i].day;
        cout << "Month: ";
        cin >> DATE[i].month;
        cout << "Year: ";
        cin >> DATE[i].year;
    }
    cout<<"Enter Date: \n\n";
    cout << "Day: ";
    cin >> d;
    cout << "Month: ";
    cin >> m;
    cout << "Year: ";
    cin >> y;
    for(int i=0; i<n; i++)
    {
        if(DATE[i].day==d && DATE[i].month==m && DATE[i].year==y)
        {
            cout << "\nDates are equal\n";
        }
        else
        {
            cout << "\nDates are Not equal\n";
        }
    }
}
