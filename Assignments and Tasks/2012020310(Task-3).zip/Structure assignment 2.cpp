#include<bits/stdc++.h>
#include <iostream>
using namespace std;

struct student
{
    char name[50];
    int id;
    char address[50];
    float marks;
};
void sortt(student st[],int n)
{
    int temp;
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(st[i].marks>st[j].marks)
            {
            temp = st[i].marks;
            st[i].marks=st[j].marks;
            st[j].marks=temp;
            }
        }
    }
}
int main()
{
    int n;
    cout<<"Enter the number of students: ";
    cin>>n;
    student st[n];
    for(int i=0;i<n;i++)
    {
    cout << "Enter name: ";
    cin>>st[i].name;
    cout << "Enter ID: ";
    cin >> st[i].id;
    cout<<"Enter Address: ";
    cin>>st[i].address;
    cout << "Enter marks: ";
    cin >> st[i].marks;
    getchar();
    }
    sortt(st,n);
    for(int i=0;i<n;i++)
    {
    cout << "Name: " << st[i].name << endl;
    cout << "ID: " << st[i].id << endl;
    cout<<  "Address: "<<st[i].address<<endl;
    cout << "Marks: " << st[i].marks << endl;
    }
}


