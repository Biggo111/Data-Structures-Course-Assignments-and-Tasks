#include<bits/stdc++.h>
#include <iostream>
using namespace std;

struct student
{
    string name;
    string acc;
    int balance;
};
void balancee(student st[],int n)
{
    for(int i=0; i<n; i++)
    {
        if(st[i].balance<200)
        {
            cout << "Name of the customer who has the amount less than $200: " << st[i].name << endl;
        }
    }
}
void add(student st[],int n)
{
    for(int i=0; i<n; i++)
    {
        if(st[i].balance>=1000)
        {
            st[i].balance+=100;
            cout << "Updated Balance of the customer who has amount more than $1000: " << st[i].balance << endl;
        }
    }
}
int main()
{
    int n;
    cout<<"Enter the number of students: ";
    cin>>n;
    student st[n];
    for(int i=0;i<n;i++)
    {
    cout << "Enter name: ";
    cin>>st[i].name;
    cout<<"Enter account number: ";
    cin>>st[i].acc;
    cout<<"Enter balance: ";
    cin>>st[i].balance;
    }
    balancee(st,n);
    add(st,n);
}

