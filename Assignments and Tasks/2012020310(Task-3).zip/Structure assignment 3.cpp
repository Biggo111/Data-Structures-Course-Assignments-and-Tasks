#include<bits/stdc++.h>
#include <iostream>
using namespace std;

struct student
{
    char name[50];
    int id;
    char address[50];
    float marks;
};
bool compareid(student a,student b)
{
    if(a.id>b.id)
    {
        return true;
    }
    else
    {
        return false;
    }
}
int main()
{
    int n;
    cout<<"Enter the number of students: ";
    cin>>n;
    student st[n];
    for(int i=0;i<n;i++)
    {
    cout << "Enter name: ";
    cin>>st[i].name;
    cout << "Enter ID: ";
    cin >> st[i].id;
    cout<<"Enter Address: ";
    cin>>st[i].address;
    cout << "Enter marks: ";
    cin >> st[i].marks;
    getchar();
    }
    sort(st,st+n,compareid);
    for(int i=0;i<n;i++)
    {
    cout << "Name: " << st[i].name << endl;
    cout << "ID: " << st[i].id << endl;
    cout<<  "Address: "<<st[i].address<<endl;
    cout << "Marks: " << st[i].marks << endl;
    }
}



